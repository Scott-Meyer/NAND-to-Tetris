Completed:

Array.jack
Math.jack