Project 11 Compiler.


Possible problems:
	the bit converter, I had problems where I couldn't enter a number into memory[8000]. Happened with normal compiled also so maybe it works?
	Complex array test2 gets expected 40, actual 0... though I still can't figure it out

To run:

Option1: I have python3 (python3!!!! not 2) and I want to run your file

Simply run project11.py like any python 3 file.


Option2: I want to try out your distributable EXE.
(Not sure this works, I tried to test it. Its made with (pyinstaller).

IF you can't get python36 interpreter to run the file, and you can't get this to run PLEASE contact me fast so I can work something out

Go on into the 'dist/project11' and double click project11.exe.



To use:
After the prompt just enter a folder name or .jack file name.

Allows for partial. So if you run from a folder that includes the folders to compile you can just do "Seven"
	(this is hard to do with the dist, because it needs all those random files)