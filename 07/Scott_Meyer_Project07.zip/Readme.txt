To use VMTranslator:

Extract entire "VMtranslator" folder.
Open and run "VMtranslator.exe"

When prompted, enter path to VM files (May be a specific file, or a folder containing the VM)
	If choosing to enter path to folder, do not leave a tailing /. 
		For example:	Correct: tests/MemoryAccess/BasicTest
				Incorrect: test/MemoryAccess/BasicTest/


Once you enter a path, all the ASM made will be printed into the terminal, but also saved to the location of the VM you entered.
You may now enter another path.

Close to exit.