Requires Python3 to run (#3).

Once you have python working, open a terminal and browse to the location of
	project10.py

Once your command prompt is there, run:
	"python project10.py 'some/file/location.jack' 'some/folder_location'"

You can list as many folders/files as you want.


You will see a list of all files translated.
	The new .xml files will be saved to "file2.xml" the 2 is added incase
	you have other .xml files of the same name you are refrencing.