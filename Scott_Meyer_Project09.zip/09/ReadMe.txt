A simple hang man game.

Warning: Making the same wrong guess multiple times is counted as multiple wrong guesses.

To play simply open the nand2tetris vm emulator, and open the "HangMan" folder.