A simple hang man game.


To play simply open the nand2tetris vm emulator, and open the "HangMan" folder.